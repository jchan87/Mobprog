
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sqlflite_gui/main.dart';
import 'package:flutter_sqlflite_gui/user.dart';

class ProfileUpdate extends StatefulWidget {
  const ProfileUpdate({super.key});

  @override
  State<ProfileUpdate> createState() => _ProfileUpdateState();
}

class _ProfileUpdateState extends State<ProfileUpdate> {
  UserModel? user;
  String username = "";
  String password = "";
  String email = "";
  String fullname = "";
  DocumentReference? documentRerence = null;

  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;
  @override
  void initState() {
    super.initState();
    db
        .collection('users')
        .where('email', isEqualTo: auth.currentUser?.email)
        .limit(1)
        .get()
        .then((value) {
      final data = value.docs[0].data();

      setState(() {
        email = data['email'];
        fullname = data['fullname'];
        username = data['username'];
        documentRerence = value.docs[0].reference;
        user = UserModel(
            email: data['email'],
            fullname: data['fullname'],
            username: data['username']);
      });
    });
  }

  void changeUsername(String value) {
    print(value);
    setState(() {
      username = value;
    });
  }

  void changePassword(String value) {
    print(value);
    setState(() {
      password = value;
    });
  }

  void changeFullname(String value) {
    print(value);
    setState(() {
      fullname = value;
    });
  }

  void changeEmail(String value) {
    print(value);
    setState(() {
      email = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
              title: const Text('Update Profile'),
              leading: BackButton(
                onPressed: () {
                  Navigator.of(context).pop(context);
                },
                color: Colors.white,
              )),
          body: user == null ? waitWidget() : mainApp()),
    );
  }

  Widget mainApp() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextFormField(
          // controller: TextEditingController(
          //   text: username,
          // ),
          initialValue: username,
          textAlign: TextAlign.center,
          decoration: const InputDecoration(hintText: 'Username'),
          onChanged: (value) => changeUsername(value),
        ),
        TextFormField(
          initialValue: fullname,
          textAlign: TextAlign.center,
          decoration: const InputDecoration(hintText: 'Fullname'),
          onChanged: (value) => changeFullname(value),
        ),
        Container(
          margin: EdgeInsets.only(top: 8.0),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
            ),
            onPressed: () {
              // onSubmit();
              final user = <String, dynamic>{
                "fullname": fullname,
                "username": username,
                "email": email
              };
              documentRerence?.update(user).then((value) {
                print('testr');
                Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => const MyApp()));
              });
            },
            child: const Text('Submit', selectionColor: Colors.white),
          ),
        ),
      ],
    );
  }

  Widget waitWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [CircularProgressIndicator()],
        )
      ],
    );
  }
}
