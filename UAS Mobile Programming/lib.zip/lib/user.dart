
class UserModel{
  String email, fullname, username;
  UserModel({required this.email, required this.fullname, required this.username});

  set password(String password) {}
}