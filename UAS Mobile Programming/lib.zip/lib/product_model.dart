class ProductModel{
  int? id;
  String? name, category,createAt,updateAt;

  ProductModel({this.id,this.name,this.category,this.createAt,this.updateAt});

  factory ProductModel.fromJson(Map<String,dynamic> json){
    return ProductModel(
      id: json['id'],
      name: json['name'],
      category: json['category'],
      createAt: json['created_at'],
      updateAt: json['updated_at']
    );
  }
}