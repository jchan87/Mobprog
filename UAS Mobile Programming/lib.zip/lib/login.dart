import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sqlflite_gui/main.dart';
import 'package:flutter_sqlflite_gui/register.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginScreenWidget(
        key: key,
      ),
    );
  }
}

class LoginScreenWidget extends StatefulWidget {
  const LoginScreenWidget({super.key});

  @override
  State<StatefulWidget> createState() => _LoginScreenWidgetState();
}

class _LoginScreenWidgetState extends State<LoginScreenWidget> {
  String email = "";
  String password = "";
  void changeEmail(String value) {
    print(value);
    setState(() {
      email = value;
    });
  }

  void changePassword(String value) {
    print(value);
    setState(() {
      password = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    print(FirebaseAuth.instance.currentUser);
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'Email'),
              onChanged: (value) => changeEmail(value),
            ),
            TextField(
              textAlign: TextAlign.center,
              obscureText: true,
              decoration: const InputDecoration(hintText: 'password'),
              onChanged: (value) => changePassword(value),
            ),
            Container(
              margin: const EdgeInsets.only(top: 8.0),
              child: ElevatedButton(
                onPressed: () {
                  onSubmit();
                },
                child: const Text('Submit'),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text('Does not have account? Register here : '),
                TextButton(
                  onPressed: () {
                    onRegister();
                  },
                  child: const Text('Register'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void onRegister() {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => const RegisterScreen()))
        .then((value) {
          setState(() {});
        });
  }

  void onSubmit() async {
    // FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: password).then((value) => {
    //     print(value)
    // }).onError((error, stackTrace) => {
    //   print('register error')
    // });
    try {
      await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password)
          .then((value) => {
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => const MyApp()))
              });
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text(
            'Email or Password is incorrect'),
      ));
    }

    // Navigator.push(
    //     context, MaterialPageRoute(builder: (context) => const MyApp()));
  }
}
