import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_sqlflite_gui/main.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RegisterScreenWidget(
        key: key,
      ),
    );
  }
}

class RegisterScreenWidget extends StatefulWidget {
  const RegisterScreenWidget({super.key});

  @override
  State<StatefulWidget> createState() => _RegisterScreenWidgetState();
}

class _RegisterScreenWidgetState extends State<RegisterScreenWidget> {
  String username = "";
  String password = "";
  String email = "";
  String fullname = "";
  final db = FirebaseFirestore.instance;
  void changeUsername(String value) {
    print(value);
    setState(() {
      username = value;
    });
  }

  void changePassword(String value) {
    print(value);
    setState(() {
      password = value;
    });
  }

  void changeFullname(String value) {
    print(value);
    setState(() {
      fullname = value;
    });
  }

  void changeEmail(String value) {
    print(value);
    setState(() {
      email = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          color: Colors.white,
          onPressed: () =>
              Navigator.of(context, rootNavigator: true).pop(context),
        ),
        title: const Text('Register'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'Username'),
              onChanged: (value) => changeUsername(value),
            ),
            TextField(
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'Fullname'),
              onChanged: (value) => changeFullname(value),
            ),
            TextField(
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'Email'),
              onChanged: (value) => changeEmail(value),
            ),
            TextField(
              textAlign: TextAlign.center,
              obscureText: true,
              decoration: const InputDecoration(hintText: 'password'),
              onChanged: (value) => changePassword(value),
            ),
            Container(
              margin: EdgeInsets.only(top: 8.0),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                ),
                onPressed: () {
                  onSubmit();
                },
                child: const Text('Submit', selectionColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onSubmit() {
    print('test');

    FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password)
        .then((value) {
      print(value);
      final user = <String, dynamic>{
        "fullname": fullname,
        "username": username,
        "email": email
      };
      db.collection("users").add(user).then((DocumentReference doc) {
        print('DocumentSnapshot added with ID: ${doc.id}');
        Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => const MyApp()));
      });
    }).onError((error, stackTrace) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text(
            'Something wrong with the input, Please make sure that email formated well and password more than or equal 6 character'),
      ));
    });
  }
}
