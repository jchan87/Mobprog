import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sqlflite_gui/login.dart';
import 'package:flutter_sqlflite_gui/profile_update.dart';
import 'package:flutter_sqlflite_gui/user.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  UserModel? user;

  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;
  @override
  void initState() {
    super.initState();
    db
        .collection('users')
        .where('email', isEqualTo: auth.currentUser?.email)
        .limit(1)
        .get()
        .then((value) {
      final data = value.docs[0].data();
      setState(() {
        user = UserModel(
            email: data['email'],
            fullname: data['fullname'],
            username: data['username']);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Profile'),
          actions: [
            IconButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (builder) {
                  return const ProfileUpdate();
                }));
              },
              icon: const Icon(Icons.update_rounded))
          ],
        ),
        // body: Con,
        body: user == null ? waitWidget() : mainPage(),
        // body: user mainPage(),
      ),
    );
  }

  Widget mainPage() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.email),
            Text(user!.email),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.account_circle),
            Text(
              user!.username,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.abc_sharp),
            Text(
              user!.fullname,
            ),
          ],
        ),
        Container(
          margin: const EdgeInsets.only(top: 8.0),
          child: ElevatedButton(
            onPressed: () {
              FirebaseAuth.instance.signOut().then((value) {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const LoginScreen()));
              });
            },
            child: const Text('Log Out'),
          ),
        ),
      ],
    );
  }

  Widget waitWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [CircularProgressIndicator()],
        )
      ],
    );
  }
}
